// JavaScript Document


//examen unam 

  var examen='2 y 3 de junio';
  var lugar='Ciudad de M&eacute;xico';
  var convocatoria='';
  var registro='21 de abril al 11 de mayo';
  var anio=2012;
  var resultados='15 de julio';
  
  var dia='S&aacute;bados y domingos';
  var curso='14 de abril al 27 de mayo';
  var horario='9:00 am a 4:00 pm';
  var sede='Pestalozzi 711 Col. del Valle C.P. 03100';  
  
    <!-- Aweber Web Form

    (function() {
        var IE = /*@cc_on!@*/false;
        if (!IE) { return; }
        if (document.compatMode && document.compatMode == 'BackCompat') {
            if (document.getElementById("af-form-497803880")) {
                document.getElementById("af-form-497803880").className = 'af-form af-quirksMode';
            }
            if (document.getElementById("af-body-497803880")) {
                document.getElementById("af-body-497803880").className = "af-body inline af-quirksMode";
            }
            if (document.getElementById("af-header-497803880")) {
                document.getElementById("af-header-497803880").className = "af-header af-quirksMode";
            }
            if (document.getElementById("af-footer-497803880")) {
                document.getElementById("af-footer-497803880").className = "af-footer af-quirksMode";
            }
        }
    })();

<!-- /AWeber Web Form Generator 3.0 -->
    -->
  
