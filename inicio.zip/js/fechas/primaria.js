

	// Examen

  var examen='4 de Junio';

  var lugar='Rep&uacute;blica Mexicana';

  var registro='5 al 16 de Mayo';

  var anio=2014;

  var resultados='resultados 20 de Junio';

  var tipo='Presencial';
  
  
  <!--Lugar y Sede1-->
  
  var lugar='Ciudad de M&eacute;xico';  
  var sede='Av. Cuauht&eacute;moc No. 876 Col. Narvarte, C.P. 03020 <br> Tel&eacute;fono: (55) 6395 0240';


	// Curso

  var dia='S&aacute;bados y Domingos';

  var curso='12 de Abril al 1 de Junio';

  var horario='9:00 a.m. a 2:00 p.m.';

<!--  var sede='Cuauht&eacute;moc 876, Narvarte, C.P. 03020';-->

  

// Opcion 2

  

	// Examen

  var examenb='26 de agosto';

  var lugarb='Toda la República ';

  var registrob='25 de junio al 27 de julio';

  var aniob=2012;

  var resultadosb='12 de octubre';

  var tipob='escrito';

	// Curso

  var diab='S&aacute;bados y Domingos';

  var cursob='21 de julio al 25 de agosto';

  var horariob='9:00 am a 3:00pm';

  var sedeb='Pestalozzi 711 Col. del Valle C.P. 03100';

 
  <!--Lugar y Sede2-->
  
  var lugarqro='Quer&eacute;taro';  
  var sedeqro='Av. universidad y Retablo (arriba del oxxo) <br> Tel&eacute;fono:(442) 212 4712 | (442) 480 4465';
  
  <!--Curso entre semanaqro-->
  
  var diaqro='Lunes a Jueves';
  var cursoqro='6 de Julio al 24 de Agosto';
  var horarioqro='de 10:00 am a 1:00 pm';
  var horarioqro2='6:30 pm a 9:30 pm';

  <!--Curso fin semanaqro-->
  
  var diaqrob='S&aacute;bados y Domingos';
  var cursoqrob='6 de Julio al 24 de Agosto';
  var horarioqrob='9:00 am a 3:00 pm';


// WEB FORM AWEBER

  

    <!--

	 (function() {

        var IE = /*@cc_on!@*/false;

        if (!IE) { return; }

        if (document.compatMode && document.compatMode == 'BackCompat') {

            if (document.getElementById("af-form-471266109")) {

                document.getElementById("af-form-471266109").className = 'af-form af-quirksMode';

            }

            if (document.getElementById("af-body-471266109")) {

                document.getElementById("af-body-471266109").className = "af-body inline af-quirksMode";

            }

            if (document.getElementById("af-header-471266109")) {

                document.getElementById("af-header-471266109").className = "af-header af-quirksMode";

            }

            if (document.getElementById("af-footer-471266109")) {

                document.getElementById("af-footer-471266109").className = "af-footer af-quirksMode";

            }

        }

    })();

    -->

  

  

