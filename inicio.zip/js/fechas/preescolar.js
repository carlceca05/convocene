// JavaScript Document

  var examen='2 de agosto';
  var examenb='2 de agosto'
  var lugarB='Nivel nacional';
  var registro='1 de junio al 3 de julio';
  var registrob='1 de junio al de 3 julio'
  var anio=2015;
  var resultados='resultados 4 de septiembre';
  var resultadosb='resultados 4 de septiembre';

  var tipo='l&iacute;nea';

  var dia='S&aacute;bados y Domingos';
  var curso='20 de junio al 1 de agosto';
  var horario='9:00 am a 2:00 pm';
  var sede='Av. Cuauht&eacute;moc No. 876 Col. Narvarte C.P. 03020';
  
  var diab='S&aacute;bados y Domingos';
  var cursob='17 de mayo al 19 de julio';
  var horariob='8:00 am a 3:00pm';
  var sedeb='Av. universidad y Retablo (arriba del oxxo) Tel&eacute;fono:(442) 212 4712 | (442) 480 4465';
  
// WEB FORM AWEBER
  
      <!--
    (function() {
        var IE = /*@cc_on!@*/false;
        if (!IE) { return; }
        if (document.compatMode && document.compatMode == 'BackCompat') {
            if (document.getElementById("af-form-1940289589")) {
                document.getElementById("af-form-1940289589").className = 'af-form af-quirksMode';
            }
            if (document.getElementById("af-body-1940289589")) {
                document.getElementById("af-body-1940289589").className = "af-body inline af-quirksMode";
            }
            if (document.getElementById("af-header-1940289589")) {
                document.getElementById("af-header-1940289589").className = "af-header af-quirksMode";
            }
            if (document.getElementById("af-footer-1940289589")) {
                document.getElementById("af-footer-1940289589").className = "af-footer af-quirksMode";
            }
        }
    })();
    -->
  
  
