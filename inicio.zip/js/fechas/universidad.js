// JavaScript Document


//examen unam 

  var examenu='8, 9, 15 y 16 de Marzo';
  var lugaru='Ciudad de M&eacute;xico';
  var lugarqro='Quer&eacute;taro';
  var lugaroax='Oaxaca';
  var convocatoriau='8 de Enero';
  var registrou='8 al 19 de Enero';
  var aniou=2014;
  var resultadosu='9 de abril';
  
  var diau='Lunes a Viernes';
  var cursou='27 de enero al 7 de Marzo';
  var horarioum='8:00 a.m. a 1:00 p.m.';
  var horariouv='5:00 p.m. a 10:00 p.m.';
  var sedeu='Av. Cuauht&eacute;moc 876 Col. Narvarte C.P. 03020';
  
  var diaqro='Lunes, Miercoles y Viernes';
  var cursoqro='18 de marzo al 31 de mayo';
  var horarioqro='6:00 p.m. a 10:00 p.m.';
  var sedeqro='Av. Universidad y Esquina Retablo (arriba del oxxo) <br> Tel&eacute;fono:(44)2 12 47 12';
  
  var diaoax='Martes y Jueves';
  var cursooax='22 de Octubre al 23 de Enero';
  var horariooaxm='8:30 a.m. a 12:00 p.m.';
  var horariooaxv='5:00 p.m. a 8:30 p.m.';
  var sedeoax='Calzada de la Rep&uacute;blica 113 Col. centro Oaxaca de Ju&aacute;rez <br> Tel&eacute;fono:(951)51 54 206';
  
  var diaoaxb='Sabatino';
  var cursooaxb='26 de Octubre al 25 de Enero';
  var horariooaxbm='8:00 a.m. a 3:00 p.m.';
  var horariooaxbv='5:00 p.m. a 10:00 p.m.';
  var sedeoaxb='Calzada de la Rep&uacute;blica 113 Col. centro Oaxaca de Ju&aacute;rez <br> Tel&eacute;fono:(951)51 54 206';
  
  var diaub='S&aacute;bado y Domingo';
  var cursoub='30 de Noviembre al 2 de Marzo';
  var horarioub='3:00 p.m. a 8:00 p.m.';
  var sedeub='Av. Cuauht&eacute;moc 876 Col. Narvarte C.P. 03020';
  
  var diauc='Lunes a Viernes';
  var cursouc='23 de abril al 31 de mayo';
  var horariouc='5:00 p.m. a 10:00 p.m.';
  var sedeuc='Pestalozzi 711 Col. del Valle C.P. 03100';
  
  var diautc='Lunes a Viernes';
  var cursoutc='23 de abril al 18 de mayo';
  var horarioutc='6:00 p.m. a 10:00 p.m.';
  var sedeutc='Pestalozzi 711 Col. del Valle C.P. 03100';  

  var diaut='Lunes a Viernes';
  var cursout='18 de mayo al 31 de mayo';
  var horariout='6:00 p.m. a 10:00 p.m.';
  var sedeut='Pestalozzi 711 Col. del Valle C.P. 03100';  
    
//examen ipn

  var exameni='Mayo';
  var lugari='Ciudad de México';
  var convocatoriai='Marzo';
  var registroi='Marzo-Abril';
  var anioi=2014;
  var resultadosi='resultados en Julio';
  
  var diai='Domingos';
  var cursoi='12 de Enero al 18 de mayo';
  var horarioi='8:00 am a 3:00 pm';
  var sedei='Av. Cuauht&eacute;moc 876 Col. Narvarte C.P. 03020';
  
  var diaib='Sabados y  domingos';
  var cursoib='4 al 18 de mayo';
  var horarioib='9:00 am a 5:00 pm';
  var sedeib='Pestalozzi 711 Col. del Valle C.P. 03100';
  
  var diaiqro='Lunes, Miercoles y Viernes';
  var cursoiqro='18 de marzo al 24 de mayo';
  var horarioiqro='6:00 p.m. a 10:00 p.m.';
  var sedeiqro='Av. Universidad y Esquina Retablo (arriba del oxxo) <br> Tel&eacute;fono:(44)2 12 47 12';
  
//examen uam

  var examenuam='10 o 11 de marzo';
  var lugaruam='Ciudad de México';
  var convocatoriaiuam='';
  var registrouam='6 al 21 de febrero';
  var aniouam=2012;
  var resultadosuam='resultados 13 de abril';
  
  var diauam='Lunes a viernes';
  var cursouam='13 de febrero al 9 de marzo';
  var horariouam='6:00 pm a 10:00pm';
  var sedeuam='Pestalozzi 711 Col. del Valle C.P. 03100';
  
  
  
    <!-- Aweber Web Form
    (function() {
        var IE = /*@cc_on!@*/false;
        if (!IE) { return; }
        if (document.compatMode && document.compatMode == 'BackCompat') {
            if (document.getElementById("af-form-169028378")) {
                document.getElementById("af-form-169028378").className = 'af-form af-quirksMode';
            }
            if (document.getElementById("af-body-169028378")) {
                document.getElementById("af-body-169028378").className = "af-body inline af-quirksMode";
            }
            if (document.getElementById("af-header-169028378")) {
                document.getElementById("af-header-169028378").className = "af-header af-quirksMode";
            }
            if (document.getElementById("af-footer-169028378")) {
                document.getElementById("af-footer-169028378").className = "af-footer af-quirksMode";
            }
        }
    })();
    -->
  
